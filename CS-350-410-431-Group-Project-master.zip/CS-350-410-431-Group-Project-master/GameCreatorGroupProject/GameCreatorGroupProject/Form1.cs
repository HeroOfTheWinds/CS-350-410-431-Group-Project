﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.IO;
using OpenTK;
using System.Text.RegularExpressions;

namespace GameCreatorGroupProject
{
    public partial class MainWindow : Form
    {
        MainClient main = Program.getMain();
        private List<uint> ilist = new List<uint>();
        // Create an empty Project instance
        Project project = new Project();

        // Variable to track whether a project is actively being edited
        // Necessary to ensure the user doesn't load something nonexistent
        // or exit without saving a brand new project.
        bool projectOpen = false;

        // Debug flag; used to bypass some checks or show extra information
        #if DEBUG
            bool debug = true;
#else
            bool debug = false;
#endif

        //MainClient to be created when form is loaded
        MainClient online;
        TCPClient chat;

        //private string sprloc = null;
        private Image spr = null;
        private Vector2[] cOffsets = null;
        private Vector2[] bOffsets = null;

        private uint chatServerID;

        // Declare a ResourceImporter to make it easier to load and save resources
        ResourceImporter resImporter = new ResourceImporter();

        public MainWindow()
        {
            InitializeComponent();
        }

        // manually created button for the add to list function
        private static class Prompt
        {
            public static string ShowDialog(string text, string caption)
            {
                Form prompt = new Form()
                {
                    Width = 500,
                    Height = 150,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = caption,
                    StartPosition = FormStartPosition.CenterScreen
                };
                Label textLabel = new Label() { Left = 50, Top = 20, Text = text };
                TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 400 };
                Button confirmation = new Button() { Text = "Ok", Left = 350, Width = 100, Top = 70, DialogResult = DialogResult.OK };
                confirmation.Click += (sender, e) => { prompt.Close(); };
                prompt.Controls.Add(textBox);
                prompt.Controls.Add(confirmation);
                prompt.Controls.Add(textLabel);
                prompt.AcceptButton = confirmation;

                return prompt.ShowDialog() == DialogResult.OK ? textBox.Text : "";
            }
        }

        private void itemStartServer_Click(object sender, EventArgs e)
        {
            // If no project is open, throw error and abandon function
            if (!projectOpen && !debug)
            {
                MessageBox.Show("Error: No currently open projects.");
                return;
            }

            //Connect to mainServer using ServerInfo
            connect();


            // Create a server
            //ChatServer prjServer = new ChatServer();

            // Start it up
            //prjServer.startServer(project);

            return;
        }

        // This function is called whenever the user clicks File>New on the tool bar.
        private void itemNew_Click(object sender, EventArgs e)
        {
            // Use VisualBasic's input box to get the project name from the user
            string newName = Interaction.InputBox("Enter the project name:", "Enter Project Name", "NewProject", -1, -1);

            // Get the folder from the user
            folderPrjDir.ShowDialog();

            string targetPath = folderPrjDir.SelectedPath + "/" + newName;

            // Create the project directory if necessary.
            if (!System.IO.Directory.Exists(targetPath))
            {
                System.IO.Directory.CreateDirectory(targetPath);
            }

            // Generate the path to the resources folder
            string resPath = targetPath + "/Resources";

            // Create Resources directory if it doesn't exist
            if (!System.IO.Directory.Exists(resPath))
            {
                System.IO.Directory.CreateDirectory(resPath);
            }

            // Create a new project instance
            project.setName(newName);
            project.setDirectory(targetPath);
            project.setResourceDir(resPath);

            // Save to file
            project.SaveProject();

            // Set variable to say there is an open project.
            projectOpen = true;
        
            return;
        }

        // This function is called when the user clicks the Add button in the Resource Manager.
        private void btnAddResource_Click(object sender, EventArgs e)
        {
            // If no project is open, throw error and abandon function
            if (!projectOpen)
            {
                MessageBox.Show("Error: No currently open projects.");
                return;
            }

            // Get the path to the resource from the user
            openResourceDialog.ShowDialog();

            // Use an input box to get the resource name from the user
            string newName = Interaction.InputBox("Enter the resource's name:", "Enter Resource Name", "Resource1", -1, -1);

            // Get extension of the file
            string fileExt = Path.GetExtension(openResourceDialog.FileName);

            // Save the resource in the project and copy file to resource folder
            resImporter.SaveResource(project, newName, fileExt, openResourceDialog.FileName);

            // Show resource in list view
            listResources.Items.Add(newName);
        }

        // Show the preview of the image when selected, and its file properties
        private void listResources_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Look up item in the resource list to get path and display in the preview pane.
            picPreview.ImageLocation = project.Resources[listResources.SelectedItem.ToString()];

            // Set the file property display to the right of the preview
            // Clear previous lists for new display
            listFPVals.Items.Clear();
            listFProperties.Items.Clear();

            // Add File Name property
            listFProperties.Items.Add("File name:");
            listFPVals.Items.Add(Path.GetFileName(project.Resources[listResources.SelectedItem.ToString()]).ToString());

            // Add Creation Date property
            listFProperties.Items.Add("Date created:");
            listFPVals.Items.Add(File.GetCreationTime((project.Resources[listResources.SelectedItem.ToString()]).ToString()));

            // Add File Size property
            listFProperties.Items.Add("File size:");
            listFPVals.Items.Add((new FileInfo((project.Resources[listResources.SelectedItem.ToString()])).Length.ToString() + " bytes"));
        }

        private void itemSave_Click(object sender, EventArgs e)
        {
            // If no project is open, throw error and abandon function
            if (!projectOpen)
            {
                MessageBox.Show("Error: No currently open projects.");
                return;
            }

            // Save the project
            int errNum = project.SaveProject();

            if (errNum == 55)
            {
                // File was open in another application, tell user we failed.
                MessageBox.Show("Error: File still open in another process. Could not save.");
            }
        }

        private void itemExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void itemOpen_Click(object sender, EventArgs e)
        {
            // Set the file open dialog to only show .prj files
            openResourceDialog.Filter = "Project Files (*.prj)|*.prj|All Files (*.*)|*.*";
            // Prompt user for project file
            openResourceDialog.ShowDialog();
            // Restore filter to unfiltered state
            openResourceDialog.Filter = "All Files (*.*)|*.*";
             
            // Grab user-selected path
            string projPath = openResourceDialog.FileName;

            // Load data into current project
            project.LoadProject(projPath);

            // Clear out the list of resources the user sees
            listResources.Items.Clear();

            // Update the list of resources viewed by the user
            foreach (string resName in project.Resources.Keys)
            {
                listResources.Items.Add(resName);
            }
        }

        private void itemConnect_Click(object sender, EventArgs e)
        {
            chatServerID = online.requestChatServer();
            MessageBox.Show("Connected to chat server: " + chatServerID.ToString());

            chat = online.getAvailable();

            //ChatWindow cw = new ChatWindow(chat);
            //cw.Show();

            //online.connectClient(1, chatServerID, 1);
            //chat = MainClient.clients.ElementAt(0);
            //chat.connectClient(ServerInfo.getServerIP());
        }

        private void MainWindow_Load(object sender, EventArgs e)
        {
            online = new MainClient();
        }

        public void connect()
        {
            Thread t = new Thread(connectMain);
            t.Start();
        }

        //connects the main client to the server
        private void connectMain()
        {
            online.connectClient(ServerInfo.getServerIP());
        }

        private void MainWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            online.disconnect();
        }

        private void sendMessageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string msg = "Hello World!";
            object temp = msg;
            if (chat == null)
                chat = online.getAvailable();
            chat.send(ref temp);
        }

        private void addUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void addUserDebugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            online.connectClient(1, chatServerID, 0);
        }

        private void addUserReleaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            online.connectClient(1, chatServerID, 1);
        }

        private void radioSprite_MouseDown_1(object sender, MouseEventArgs e)
        {
            
        }

        private void btnSetSprite_Click(object sender, EventArgs e)
        {
            try
            {
                spr = Image.FromFile(cmbSprite.Text);
                CollisionDesigner.spr = spr;
                picSpriteView.Image = spr;
                radioBox.Enabled = true;
                radioSprite.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid Sprite.", "Invalid sprite selection.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            if (d.ShowDialog() == DialogResult.OK)
            {
                cmbSprite.Text = d.FileName;
                //sprloc = d.FileName;
            }
        }

        private void radioSprite_Click(object sender, EventArgs e)
        {
            CollisionDesigner d = new CollisionDesigner();
            d.ShowDialog(this);
            cOffsets = CollisionDesigner.offsets;
            //have something ask for width and height and scale off that
        }

        private void btnAddObject_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            if (d.ShowDialog() == DialogResult.OK)
            {
                //file must end in .gob, can change if want
                Regex ob = new Regex(@".*\.gob$");
                Regex c = new Regex(@".*\.goc$");
                if (ob.Match(d.FileName).Success)
                {
                    //parse file for validity, print error if incorrect, else add to object collection
                    File.Copy(d.FileName, project.getResourceDir());
                }
                else if (c.Match(d.FileName).Success)
                {
                    //parse file for validity, print error if incorrect, else add to object collection
                    File.Copy(d.FileName, project.getResourceDir());
                }
                else
                {
                    MessageBox.Show("Invalid game object file.", "Invalid file.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void radioBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioBox_Click(object sender, EventArgs e)
        {
            //have things to ask for width and height and make box from that
        }

        private void listObjects_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSaveObj_Click(object sender, EventArgs e)
        {
            if (spr == null || (radioBox.Checked && bOffsets == null) || (radioSprite.Checked && cOffsets == null) || txtObjectName.Text.Equals(""))
            {
                MessageBox.Show("Game objects must have a valid sprite, collision box, and name to be saved.", "Unable to generate game object.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string file = project.getResourceDir() + txtObjectName.Text + ".gob";
                if (File.Exists(file))
                {
                    int i = 0;
                    while (File.Exists(file + i.ToString()))
                    {
                        i++;
                    }
                    file = file + i.ToString();
                }
                //write stuff to file
            }
            
        }

        private void btnRemoveObject_Click(object sender, EventArgs e)
        {
            //something like this
            //File.Delete(listObjects.SelectedItem.)
        }

        private void refresh_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < ilist.Count; i++)
            {
                if (main.isOnline(ilist[i]) == true)
                {
                    listBox.Items.Add(ilist[i] + " Online");
                }
                else
                   listBox.Items.Add(ilist[i] + " Offline");
            }
        }

        private void addToList_Click(object sender, EventArgs e)
        {
            string text;
            uint ID;
            text = Prompt.ShowDialog("Insert ClientID", "Add to List");
            //Interaction.InputBox("instert ID");
            if (UInt32.TryParse(text, out ID) == true)
            {
                ilist.Add(ID);
            }
            else
            {
                MessageBox.Show("thats number is not proper");
            }
        }

        private void peopleOnline_Click(object sender, EventArgs e)
        {
            if (listBox.Visible == true)
            {
                listBox.Visible = false;
            }
            else
                listBox.Visible = true;
        }

        private void listBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (listBox.Visible == true)
            {
                int index = this.listBox.IndexFromPoint(e.Location);
                if (index != System.Windows.Forms.ListBox.NoMatches)
                {
                    DialogResult result = MessageBox.Show("Would you like to connect to the chat?", "Chat Dialogue", MessageBoxButtons.YesNo);
                    if (result.ToString() == "Yes")
                    {
                        MessageBox.Show("Magnificent");
                    }
                }
            }
        }
    }
}
